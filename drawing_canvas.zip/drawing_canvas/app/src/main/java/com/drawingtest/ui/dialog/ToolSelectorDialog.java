package com.drawingtest.ui.dialog;

import android.support.v7.app.AlertDialog;
import android.app.Dialog;
import android.app.DialogFragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import com.drawingtest.R;

public class ToolSelectorDialog extends DialogFragment implements AdapterView.OnItemSelectedListener {
    Spinner spinner;
    String[] tools = {"Pencil","Rectangle","Circle","Triangle"};
    int val=0;

    private OnToolSelectedListener mOnToolSelectedListener;

    private AlertDialog mDialog;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder b = new  AlertDialog.Builder(getActivity())
                .setTitle("Select stroke")
                .setPositiveButton("Ok",
                        new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {

                            }
                        }
                )
                .setNegativeButton("Cancel",
                        new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int whichButton)
                            {
                                dialog.dismiss();
                            }
                        }
                );

        LayoutInflater i = getActivity().getLayoutInflater();
        View view = i.inflate(R.layout.fragment_dialog_stroke_selector, null);
        initControls(view);

        b.setView(view);

        mDialog = b.create();

        mDialog.setOnShowListener(new DialogInterface.OnShowListener() {
            @Override
            public void onShow(DialogInterface dialog) {
                Button b = mDialog.getButton(AlertDialog.BUTTON_POSITIVE);
                b.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        if (mOnToolSelectedListener != null)
                        {
                            //mOnToolSelectedListener.onToolSelected();
                            mDialog.dismiss();
                        }
                    }
                });
            }
        });

        return mDialog;
    }

    private void initControls(View v)
    {
        spinner = (Spinner) v.findViewById(R.id.tool_selector_sp);
        //ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(, R.array.tools, android.R.layout.simple_spinner_item);
        //adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        //spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        val=i;
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    public interface OnToolSelectedListener{
        public void onToolSelected(int tool);
    }
}
