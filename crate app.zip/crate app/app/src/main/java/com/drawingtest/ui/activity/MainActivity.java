package com.drawingtest.ui.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.xdty.preference.colorpicker.ColorPickerDialog;
import org.xdty.preference.colorpicker.ColorPickerSwatch;

import butterknife.Bind;
import butterknife.ButterKnife;
import butterknife.OnClick;
import com.drawingtest.R;
import com.drawingtest.domain.manager.FileManager;
import com.drawingtest.domain.manager.PermissionManager;
import com.drawingtest.ui.component.DrawingView;
import com.drawingtest.ui.dialog.StrokeSelectorDialog;

public class MainActivity extends AppCompatActivity
{
	@Bind(R.id.main_drawing_view) DrawingView mDrawingView;
	@Bind(R.id.main_fill_iv) ImageView mFillBackgroundImageView;
	@Bind(R.id.main_color_iv) ImageView mColorImageView;
	@Bind(R.id.main_stroke_iv) ImageView mStrokeImageView;
	@Bind(R.id.main_undo_iv) ImageView mUndoImageView;
	@Bind(R.id.main_redo_iv) ImageView mRedoImageView;

	private int mCurrentBackgroundColor;
	private int mCurrentColor;
	private int mCurrentStroke;
	private static final int MAX_STROKE_WIDTH = 50;

	private static final String GRID_PREFS = "gridSharedPreferences";
	private static final String SAVED_WIDTH = "gridWidth";
	private static final String SAVED_HEIGHT = "gridHeight";
	private static final String SAVED_MAXSTACK = "gridMaxStack";

	private TextView viewLable;

	private int cWidth=10, cHeight=10, cStackMax=10;
	private int maxDim =20;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);

		ButterKnife.bind(this);

		loadGrid();
		initDrawingView();

		this.viewLable = (TextView) findViewById(R.id.textView);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.menu_main, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item)
	{
		switch (item.getItemId())
		{
			case R.id.action_share:
				requestPermissionsAndSaveBitmap();
				break;
			case R.id.action_clear:
				mDrawingView.clearCanvas();
				break;
		}

		return super.onOptionsItemSelected(item);
	}

	private void initDrawingView()
	{
		mCurrentBackgroundColor = ContextCompat.getColor(this, android.R.color.white);
		mCurrentColor = ContextCompat.getColor(this, android.R.color.black);
		mCurrentStroke = 10;

		mDrawingView.setBackgroundColor(mCurrentBackgroundColor);
		mDrawingView.setPaintColor(mCurrentColor);
		mDrawingView.setPaintStrokeWidth(mCurrentStroke);
		mDrawingView.remakeGrid(cHeight,cWidth,cStackMax);
	}

	private void startFillBackgroundDialog()
	{
		int[] colors = getResources().getIntArray(R.array.palette);

		ColorPickerDialog dialog = ColorPickerDialog.newInstance(R.string.color_picker_default_title,
				colors,
				mCurrentBackgroundColor,
				5,
				ColorPickerDialog.SIZE_SMALL);

		dialog.setOnColorSelectedListener(new ColorPickerSwatch.OnColorSelectedListener()
		{

			@Override
			public void onColorSelected(int color)
			{
				mCurrentBackgroundColor = color;
				mDrawingView.setBackgroundColor(mCurrentBackgroundColor);
			}

		});

		dialog.show(getFragmentManager(), "ColorPickerDialog");
	}

	private void startColorPickerDialog()
	{
		int[] colors = getResources().getIntArray(R.array.palette);

		ColorPickerDialog dialog = ColorPickerDialog.newInstance(R.string.color_picker_default_title,
				colors,
				mCurrentColor,
				5,
				ColorPickerDialog.SIZE_SMALL);

		dialog.setOnColorSelectedListener(new ColorPickerSwatch.OnColorSelectedListener()
		{

			@Override
			public void onColorSelected(int color)
			{
				mCurrentColor = color;
				mDrawingView.setPaintColor(mCurrentColor);
			}

		});

		dialog.show(getFragmentManager(), "ColorPickerDialog");
	}

	private void startStrokeSelectorDialog()
	{
		StrokeSelectorDialog dialog = StrokeSelectorDialog.newInstance(mCurrentStroke, 20);

		dialog.setOnStrokeSelectedListener(new StrokeSelectorDialog.OnStrokeSelectedListener()
		{
			@Override
			public void onStrokeSelected(int stroke)
			{
				mCurrentStroke = stroke;
				mDrawingView.setPaintStrokeWidth(mCurrentStroke);
			}
		});

		dialog.show(getSupportFragmentManager(), "StrokeSelectorDialog");
	}

	private void startShareDialog(Uri uri)
	{
		Intent intent = new Intent();
		intent.setAction(Intent.ACTION_SEND);
		intent.setType("image/*");

		intent.putExtra(android.content.Intent.EXTRA_SUBJECT, "");
		intent.putExtra(android.content.Intent.EXTRA_TEXT, "");
		intent.putExtra(Intent.EXTRA_STREAM, uri);
		startActivity(Intent.createChooser(intent, "Share Image"));
	}

	private void requestPermissionsAndSaveBitmap()
	{
		if (PermissionManager.checkWriteStoragePermissions(this))
		{
			Uri uri = FileManager.saveBitmap(mDrawingView.getBitmap());
			startShareDialog(uri);
		}
	}

	@Override
	public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults)
	{
		super.onRequestPermissionsResult(requestCode, permissions, grantResults);
		switch (requestCode)
		{
			case PermissionManager.REQUEST_WRITE_STORAGE:
			{
				if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
				{
					Uri uri = FileManager.saveBitmap(mDrawingView.getBitmap());
					startShareDialog(uri);
				} else
				{
					Toast.makeText(this, "The app was not allowed to write to your storage. Hence, it cannot function properly. Please consider granting it this permission", Toast.LENGTH_LONG).show();
				}
			}
		}
	}

	private void startDimensionsDialog(){
		AlertDialog.Builder mBuilder = new AlertDialog.Builder(this);
		View mView = getLayoutInflater().inflate(R.layout.dimension_selector,null);
		mBuilder.setTitle("Select Dimensions");
		final SeekBar wSeekBar = (SeekBar) mView.findViewById(R.id.width_sb);
		final SeekBar hSeekBar = (SeekBar) mView.findViewById(R.id.height_sb);
		final SeekBar mSeekBar = (SeekBar) mView.findViewById(R.id.stackMax_sb);

		final TextView wOut = (TextView) mView.findViewById(R.id.width_output);
		final TextView hOut = (TextView) mView.findViewById(R.id.height_output);
		final TextView mOut = (TextView) mView.findViewById(R.id.stackMax_output);

		wOut.setText(Integer.toString(cWidth));
		hOut.setText(Integer.toString(cHeight));
		mOut.setText(Integer.toString(cStackMax));

		wSeekBar.setMax(maxDim-1);
		hSeekBar.setMax(maxDim-1);
		mSeekBar.setMax(maxDim-1);

		wSeekBar.setProgress(cWidth-1);
		hSeekBar.setProgress(cHeight-1);
		mSeekBar.setProgress(cStackMax-1);

		hSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
				hOut.setText(Integer.toString(i+1));
				mDrawingView.remakeGrid(i+1,cWidth,cStackMax);
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {

			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {

			}
		});

		wSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
				wOut.setText(Integer.toString(i+1));
				mDrawingView.remakeGrid(cHeight,i+1,cStackMax);
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {

			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {

			}
		});


		mSeekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
			@Override
			public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
				mOut.setText(Integer.toString(i+1));
				mDrawingView.remakeGrid(cHeight,cWidth,i+1);
			}

			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {

			}

			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {

			}
		});


		mBuilder.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
			@Override
			public void onClick(DialogInterface dialogInterface, int i) {

				cHeight = hSeekBar.getProgress()+1;
				cWidth = wSeekBar.getProgress()+1;
				cStackMax = mSeekBar.getProgress()+1;

				mDrawingView.remakeGrid(cHeight,cWidth,cStackMax);

				//TODO save grid dimensions here
				saveGrid();

				dialogInterface.dismiss();
			}
		});

		mBuilder.setView(mView);
		AlertDialog dialog = mBuilder.create();
		dialog.show();
	}

	private void saveGrid(){
		SharedPreferences sharedPreferences = getSharedPreferences(GRID_PREFS,MODE_PRIVATE);
		SharedPreferences.Editor editor = sharedPreferences.edit();

		editor.putInt(SAVED_HEIGHT,cHeight);
		editor.putInt(SAVED_WIDTH,cWidth);
		editor.putInt(SAVED_MAXSTACK,cStackMax);
		editor.apply();
	}

	private void loadGrid(){
		SharedPreferences sharedPreferences = getSharedPreferences(GRID_PREFS,MODE_PRIVATE);
		cHeight=sharedPreferences.getInt(SAVED_HEIGHT,10);
		cWidth=sharedPreferences.getInt(SAVED_WIDTH,10);
		cStackMax=sharedPreferences.getInt(SAVED_MAXSTACK,10);
	}

	@OnClick(R.id.main_fill_iv)
	public void onBackgroundFillOptionClick() {	mDrawingView.generateRandomGrid(); }

	@OnClick(R.id.main_color_iv)
	public void onColorOptionClick()
	{
			startDimensionsDialog();
	}

	@OnClick(R.id.main_stroke_iv)
	public void onStrokeOptionClick()
	{
		viewLable.setText("Top View");
		mDrawingView.setmView(0);
	}

	@OnClick(R.id.main_undo_iv)
	public void onUndoOptionClick()
	{
		viewLable.setText("Front View");
		mDrawingView.setmView(1);
	}

	@OnClick(R.id.main_redo_iv)
	public void onRedoOptionClick()
	{
		viewLable.setText("Side View");
		mDrawingView.setmView(2);
	}
}
