package com.drawingtest.ui.component;

import android.widget.ArrayAdapter;

import java.util.ArrayList;

public class Grid {

    int width;
    int height;
    int stackMax;

    ArrayList<ArrayList<Integer>> gridValue = new ArrayList<ArrayList<Integer>>();

    public Grid(int width, int height, int stackMax){
        System.out.println("initialize");
        this.width=width;
        this.height=height;
        this.stackMax=stackMax;

        for(int i=0;i<height;i++){
            gridValue.add(new ArrayList<Integer>());
            for(int j=0;j<width;j++){
                gridValue.get(i).add(0);
            }
        }
        System.out.println("finis initialize");
    }

    public void onCreate(){
        System.out.println("onCreate");

        System.out.println("finish onCreate");
    }

    public void generateRandomValues(){

        int i = 0;
        int j;
        double r;
        for(ArrayList<Integer> row:gridValue){
            j=0;
            for(int stack: row){
                r=Math.random();
                gridValue.get(i).set(j,(int)(r*(stackMax+1)));
               j++;
            }
            i++;
        }
    }

    public boolean hasCrate(int i, int j){
        if(gridValue.get(i).get(j)>0){
            return true;
        }else{
            return false;
        }
    }

    public int numCrate(int i, int j){
        return gridValue.get(i).get(j);

    }

    public int tallestInColoumn(int col){
        //finds the largest stack in a coloumn
        int tallest =0;

        for(ArrayList<Integer> row: gridValue){
            if(row.get(col)>tallest){
                tallest=row.get(col);
            }
        }
        return tallest;
    }

    public int tallestInRow(int row){
        //finds the largest stack in a row
        int tallest=0;

        for(int stack:gridValue.get(row)){
            if(stack>tallest){
                tallest=stack;
            }
        }
        return tallest;
    }

    public int sideDepth(int row, int height){
        int i=0;
        for(int stack:gridValue.get(row)){
            if(stack>=height){
                return i;
            }
            i++;
        }
        return -1;
    }

    public int frontDepth(int col,int height){
        int i=0;
        for(ArrayList<Integer> row:gridValue){
            if(row.get(col)>=height){
                return i;
            }
            i++;
        }
        return-1;
    }

    @Override
    public String toString() {
        return super.toString();
    }

    public int getWidth() {
        return width;
    }

    public void setWidth(int width) {
        this.width = width;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int height) {
        this.height = height;
    }


    public int getStackMax() {
        return stackMax;
    }



}
